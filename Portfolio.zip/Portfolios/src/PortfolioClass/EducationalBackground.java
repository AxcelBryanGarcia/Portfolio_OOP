package PortfolioClass;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Inherit.Hobby;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextArea;

public class EducationalBackground extends JFrame {

	private JPanel contentPane;
	Hobby hobbies = new Hobby();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EducationalBackground frame = new EducationalBackground();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EducationalBackground() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 914, 586);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("BACK");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				WelcomePage wp = new WelcomePage();
				wp.setVisible(true);
				dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel_1.setForeground(Color.yellow);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel_1.setForeground(Color.black);
			}
		});
		lblNewLabel_1.setBounds(10, 11, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JTextArea txtrIGraduatedIn = new JTextArea("I graduated in\r\nGeneral Roxas Elementary \r\nSchool year 2015-2016");
		txtrIGraduatedIn.setFont(new Font("Times New Roman", Font.BOLD, 13));
		txtrIGraduatedIn.setEditable(false);
		txtrIGraduatedIn.setForeground(new Color(0, 0, 0));
		txtrIGraduatedIn.setBackground(new Color(255, 255, 255));
		txtrIGraduatedIn.setBounds(10, 404, 213, 52);
		contentPane.add(txtrIGraduatedIn);
		
		JTextArea txtrIWasPart = new JTextArea("I was part on the\r\nTOP 10 in our section");
		txtrIWasPart.setEditable(false);
		txtrIWasPart.setFont(new Font("Times New Roman", Font.BOLD, 14));
		txtrIWasPart.setBounds(10, 469, 188, 42);
		contentPane.add(txtrIWasPart);
		
		JTextArea txtrIGraduatedIn_1 = new JTextArea("I graduated in \r\nManuel Roxas Highschool \r\nschool year 2019-2020");
		txtrIGraduatedIn_1.setForeground(Color.BLACK);
		txtrIGraduatedIn_1.setFont(new Font("Times New Roman", Font.BOLD, 13));
		txtrIGraduatedIn_1.setEditable(false);
		txtrIGraduatedIn_1.setBackground(Color.WHITE);
		txtrIGraduatedIn_1.setBounds(233, 404, 203, 52);
		contentPane.add(txtrIGraduatedIn_1);
		
		JTextArea txtrIWasPart_1 = new JTextArea("I was part on the TOP 5 \r\nin our section");
		txtrIWasPart_1.setEditable(false);
		txtrIWasPart_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		txtrIWasPart_1.setBounds(233, 470, 203, 42);
		contentPane.add(txtrIWasPart_1);
		
		JTextArea txtrIGraduatedIn_1_1 = new JTextArea("I graduated in NU-Nazareth Year 2021-2022");
		txtrIGraduatedIn_1_1.setForeground(Color.BLACK);
		txtrIGraduatedIn_1_1.setFont(new Font("Times New Roman", Font.BOLD, 13));
		txtrIGraduatedIn_1_1.setEditable(false);
		txtrIGraduatedIn_1_1.setBackground(Color.WHITE);
		txtrIGraduatedIn_1_1.setBounds(438, 404, 246, 42);
		contentPane.add(txtrIGraduatedIn_1_1);
		
		JTextArea txtrIAmCurrently = new JTextArea("I am currently studying at \r\nNational University");
		txtrIAmCurrently.setEditable(false);
		txtrIAmCurrently.setFont(new Font("Times New Roman", Font.BOLD, 13));
		txtrIAmCurrently.setBounds(694, 404, 168, 54);
		contentPane.add(txtrIAmCurrently);
		
		JTextArea txtrMyCurrentAchievement = new JTextArea("My current achievement is when \r\nI became a \r\ndean's lister last term.");
		txtrMyCurrentAchievement.setEditable(false);
		txtrMyCurrentAchievement.setFont(new Font("Times New Roman", Font.BOLD, 14));
		txtrMyCurrentAchievement.setBounds(694, 457, 208, 54);
		contentPane.add(txtrMyCurrentAchievement);
		
		JLabel lblNewLabel = new JLabel(hobbies.Age);
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 9));
		lblNewLabel.setIcon(new ImageIcon(EducationalBackground.class.getResource("/images/Educational Background .jpg")));
		lblNewLabel.setBounds(0, 0, 898, 547);
		contentPane.add(lblNewLabel);
	}
}
