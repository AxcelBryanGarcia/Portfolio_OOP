package PortfolioClass;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FrontPage extends JFrame {

	private JPanel contentPane;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrontPage frame = new FrontPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public FrontPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 907, 608);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel MORE = new JLabel("PRESS THIS TO SEE MORE INTERESTING THING ABOUT AXCEL!");
		MORE.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				WelcomePage wp = new WelcomePage();
				wp.setVisible(true);
				dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				MORE.setForeground(Color.yellow);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				MORE.setForeground(Color.black);
			}
		});
		MORE.setFont(new Font("Times New Roman", Font.BOLD, 15));
		MORE.setHorizontalAlignment(SwingConstants.CENTER);
		MORE.setBounds(193, 328, 501, 19);
		contentPane.add(MORE);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(FrontPage.class.getResource("/images/WelcomePage.png")));
		lblNewLabel.setBounds(0, 0, 891, 569);
		contentPane.add(lblNewLabel);
	}

}
