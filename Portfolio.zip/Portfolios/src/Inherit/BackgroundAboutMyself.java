package Inherit;

public class BackgroundAboutMyself {
	
	public String Name = ": Garcia, Axcel Bryan";
	public String Birthday = ": November 11, 2003";
	public String Age = ": 19 years old";
	public String Email = ": garciaaxcelbryan11@gmail.com";
	public String Address = ": 26 Gumamela Roxas District Quezon City";
	public String PhoneNumber = ": 09686110892";
	public String Strength = ": I am adaptable and capable of accomplishing the work efficiently. I am also skilled at communicating and engaging with others.";
	public String Weakness = ": Inability to make quick decisions.";
	public String Height = ": 5'9";
	
}
