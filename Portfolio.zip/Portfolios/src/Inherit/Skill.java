package Inherit;

public class Skill extends EducationalBackground{
	
	public String Skills = "Interpersonal Communication";
	public String Skills2 = "Critical Thinking";
	public String Skills3 = "Technical Skill";
	public String Skills4 = "Time Management";
}
