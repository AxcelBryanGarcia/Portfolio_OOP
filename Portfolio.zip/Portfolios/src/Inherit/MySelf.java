package Inherit;

public class MySelf {
	
	public static void main(String[] args) {
		
		BackgroundAboutMyself aboutme = new BackgroundAboutMyself();
		EducationalBackground education = new EducationalBackground();
		Skill skills = new Skill();
		Hobby hobbies = new Hobby(); 
		
		System.out.println("Background Information About Myself ");
		System.out.println("Name : " + aboutme.Name);
		System.out.println("Height : " + aboutme.Height);
		System.out.println("Birthday : " + aboutme.Birthday);
		System.out.println("Age : " + aboutme.Age);
		System.out.println("Email : " + aboutme.Email);
		System.out.println("Address: " + aboutme.Address);
		System.out.println("Phone number: " + aboutme.PhoneNumber);
		System.out.println("Strength: " + aboutme.Strength);
		System.out.println("Weakness: " + aboutme.Weakness);
		System.out.println("___________________________________");
		
		System.out.println("Educational Background ");
		System.out.println("Elementary: " + education.Elementary);
		System.out.println("Achievement: " + education.Achievement);
		System.out.println("High School: " + education.HighSchool);
		System.out.println("Achievement: " + education.Achievement2);
		System.out.println("Senior High School: " + education.SeniorHighSchool);
		System.out.println("College: " + education.College);
		System.out.println("Achievement: " + education.Achievement3);
		System.out.println("___________________________________");
		
		System.out.println("Skills");
		System.out.println("Skill 1: " + skills.Skills);
		System.out.println("Skill 2: " + skills.Skills2);
		System.out.println("Skill 3: " + skills.Skills3);
		System.out.println("Skill 4: " + skills.Skills4);
		System.out.println("___________________________________");
		
		System.out.println("Hobby");
		System.out.println("My hobby is " + hobbies.Hobby);
		
	}
}
