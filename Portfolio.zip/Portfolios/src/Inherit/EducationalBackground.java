package Inherit;

public class EducationalBackground extends BackgroundAboutMyself {
	
	public String Elementary = "I graduated in General Roxas Elementary School year 2015-2016";
	public String Achievement = "I was part on the TOP 10 in our section";
	public String HighSchool = "I graduated in Manuel Roxas Highschool school year 2019-2020";
	public String Achievement2 = "I was part on the TOP 5 in our section";
	public String SeniorHighSchool = "I graduated in NU-Nazareth year 2021-2022";
	public String College = "I am currently studying at National University";
	public String Achievement3 = "My current achievement is when I became a dean's lister last term.";
}
