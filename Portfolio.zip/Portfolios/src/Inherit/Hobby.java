package Inherit;

public class Hobby extends Skill {
	
	String Hobby = "playing Basketball";

}
